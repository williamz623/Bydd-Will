import { Component } from '@angular/core';

@Component({
  selector: 'app-buy-succeed-dialog',
  templateUrl: './buy-succeed-dialog.component.html',
  styleUrls: ['./buy-succeed-dialog.component.scss']
})
export class BuySucceedDialogComponent {

}
