import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError } from 'rxjs';

import { User } from './Models/User/User.model';
import { SharedService } from './Services/shared.service';
import { LocalStorageService } from './Services/localStorage.service';

import { MatDialog } from '@angular/material/dialog';
import { UserRegisterDialogComponent } from './user-register-dialog/user-register-dialog.component';

import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';

import * as $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  //title = 'BYDWeb';
  userSignedIn = false;
  currentUser?: User | null;
  selectedCategoryId: number = 0;
  searchKeyword: string = '';
  searchButtonDisabled:boolean=false;
  searchButtonTitle:string="Search";

  constructor(public dialog: MatDialog, private router: Router, private route: ActivatedRoute,
    private sharedService: SharedService, private localStorageService: LocalStorageService) {
  }

  ngOnInit(): void {
    this.sharedService.UserSignedIn$.subscribe(newValue => { this.userSignedIn = newValue; });
    this.sharedService.CurrentUser$.subscribe(newValue => { this.currentUser = newValue; });
  }

  gotoRouter(routerName: string) {
    if (this.userSignedIn || routerName == 'CoinList' || routerName == 'AboutUs')
      this.router.navigate(['/' + routerName]);
    else
      this.router.navigate(['/Login']);
  }

  gotoHome() { 
    this.selectedCategoryId = 0;
    this.searchKeyword="";
    this.router.navigate(['/Home']); 
  }

  logout() {
    this.localStorageService.removeData("CurrentUser");
    this.localStorageService.removeData("Token");
    this.sharedService.UpdateUserSignedIn(false);
    this.userSignedIn = false;

    this.router.navigate(['/Home']);
  }

  login() { this.router.navigate(['/Login']); }

  helpContact(){ this.router.navigate(['/HelpContact']); }

  userAgreement(){ this.router.navigate(['/UserAgreement']); }

  register() {     
    if (window.innerWidth <= 600){
      const dialogRef = this.dialog.open(UserRegisterDialogComponent, { width: '100%', height: '80%', maxWidth:'100%' }); 
    } else {
      const dialogRef = this.dialog.open(UserRegisterDialogComponent, { width: '50%', height: '80%' }); 
    }    
  }

  searchCoins() {
    this.searchButtonTitle = 'Processing...';
    this.searchButtonDisabled=true;
    const navigationExtras: NavigationExtras = { queryParams: { sw: this.selectedCategoryId + "^" + this.searchKeyword } };
    this.router.navigate(['/CoinList'], navigationExtras);

    setTimeout(() => {
      this.searchButtonTitle="Search";
      this.searchButtonDisabled=false;
    }, 750);
  }
}
