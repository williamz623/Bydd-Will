export class CoinOffer {
    userId: number = 0;
    coinId: number = 0;
    coinName: string = '';
    offerPrice: number = 0;
    offerDate?: Date;
    offerStatusCode: string=''; 
    userName:string='';
}