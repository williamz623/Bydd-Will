export class CoinShipping {
    userId: number = 0;
    coinId: number = 0;
    carrierName: string = '';
    trackingNumber:string='';
}