export class CheckOutOrder {
    userId:number = 0;
    orderIds:number[]=[];
}