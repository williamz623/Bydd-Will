export class UserBase {
    Username:string = '';
    Password:string='';
}